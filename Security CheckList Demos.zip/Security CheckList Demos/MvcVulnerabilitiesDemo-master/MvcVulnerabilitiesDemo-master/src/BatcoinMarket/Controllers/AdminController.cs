﻿using System.Web.Mvc;
using SomeBankApp.Business;

namespace SomeBankApp.Controllers
{
    public class AdminController : Controller
    {
        [ValidateInput(false)]
        public ActionResult Delete(string username)
        {
            Accounts.Delete(username);
            return RedirectToAction("Login", "Account");
        }
    }
}