﻿using SecurityCheckList.Models.SessionSniffing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecurityCheckList.DAL
{
    public static class Repository
    {
        static List<User> users = new List<User>() {

        new User() {Email="user@tatvasoft.com",Roles="Normal",Password="12345" },
        new User() {Email="Admin@tatvasoft.com",Roles="Admin",Password="12345" },
        new User() {Email="user1@tatvasoft.com",Roles="Normal",Password="Crack@777" }
    };

        public static User GetUserDetails(User user, ref string validUser)
        {
            User obj = new User();
            obj = users.Where(u => u.Email.ToLower() == user.Email.ToLower()).FirstOrDefault();
            if (obj == null)
            {
                validUser = "username";
            }
            else
            {
                obj = users.Where(u => u.Email.ToLower() == user.Email.ToLower() && u.Password == user.Password).FirstOrDefault();
                if (obj == null)
                {
                    validUser = "password";
                }
            }
            return obj;
        }
    }
}