﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Repository;

namespace SecurityCheckList.Areas.Prevention.Controllers
{
    public class XXEInjectionController : Controller
    {
        //
        // GET: /XXE/

        public enum FileExtension
        {
            gif,
            jpg,
            jpeg,
            png,
            pdf,
            tiff,
            tif,
            mtiff,
            xml,
            mp3,
            doc,
            docx,
            xls,
            xlsx,
            unknown
        }

        private static List<KeyValuePair<FileExtension, byte[]>> magicNumbers = new List<KeyValuePair<FileExtension, byte[]>>
        {
            new KeyValuePair<FileExtension, byte[]> (FileExtension.gif, new byte[] { 0x47, 0x49, 0x46, 0x38, 0x39, 0x61 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.gif, new byte[] { 0x47, 0x49, 0x46, 0x38, 0x37, 0x61 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.jpg, new byte[] { 0xFF, 0xD8 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.jpeg, new byte[] { 0xFF, 0xD8 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.png, new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.pdf, new byte[] { 0x25, 0x50, 0x44, 0x46 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.tiff, new byte[] { 0x49,0x49, 0x2A, 0x00 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.tif, new byte[] { 0x49,0x49, 0x2A, 0x00 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.mtiff, new byte[] { 0x49,0x49, 0x2A, 0x00 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.tiff, new byte[] { 0x4D, 0x4D, 0x00, 0x2A }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.tif, new byte[] { 0x4D, 0x4D, 0x00, 0x2A }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.mtiff, new byte[] { 0x4D, 0x4D, 0x00, 0x2A }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.xml, new byte[] { 0x3C, 0x3F, 0x78, 0x6D, 0x6C, 0x20 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.mp3, new byte[] { 0xFF, 0xFB }),            
            new KeyValuePair<FileExtension, byte[]> (FileExtension.doc, new byte[] { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.docx, new byte[] { 0x50, 0x4B, 0x03, 0x04 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.docx, new byte[] { 0x50, 0x4B, 0x05, 0x06 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.docx, new byte[] { 0x50, 0x4B, 0x07, 0x08 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.xls, new byte[] { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.xlsx, new byte[] { 0x50, 0x4B, 0x03, 0x04 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.xlsx, new byte[] { 0x50, 0x4B, 0x05, 0x06 }),
            new KeyValuePair<FileExtension, byte[]> (FileExtension.xlsx, new byte[] { 0x50, 0x4B, 0x07, 0x08 })
        };

        public static bool ValidateFile(string filePath, byte[] fileContent, int maxFileSize, params FileExtension[] validExtensions)
        {
            var name = Path.GetFileNameWithoutExtension(filePath);
            var extension = Path.GetExtension(filePath).TrimStart('.').ToLower();

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(extension))
            {
                throw new Exception("File Name must have a value and an extension");
            }

            if (fileContent == null || !fileContent.Any())
            {
                throw new Exception("File Content cannot be null or empty");
            }

            ////Get a list of items in valid extensions list that have no matching magic number
            var unimplementedExtensions = validExtensions.Select(ext => ext.ToString()).Except(magicNumbers.Select(num => num.Key.ToString()));

            ////If any values in valid extensions list does not have an associated magic number, throw and error
            if (unimplementedExtensions.Any())
            {
                throw new Exception("Magic number not found for file types(s): " + string.Join(",", unimplementedExtensions));
            }

            if (fileContent.Length > maxFileSize)
            {
                return false;
            }

            ////Get magic numbers for the given valid extensions
            var magicNumbersLst = magicNumbers.Where(num => validExtensions.Any(ext => num.Key == ext)).ToList();

            ////If the file type is not in the valid list it is always invalid
            if (validExtensions.All(ext => ext.ToString() != extension))
            {
                return false;
            }

            foreach (var magicNumber in magicNumbersLst)
            {
                var index = 0;
                ////If the key to be checked is longer than the file content the content cannot match the key; continue to next magicNumber
                if (magicNumber.Value.Length > fileContent.Length)
                {
                    continue;
                }

                foreach (var b in magicNumber.Value)
                {
                    ////If bytes with matching indeces don't match, move on to the next magicNumber
                    if (b != fileContent[index])
                    {
                        break;
                    }

                    index++;
                }

                ////If index reaches the length of the magic number, it has been matched
                if (index >= magicNumber.Value.Length)
                {
                    return true;
                }
            }

            ////If it still hasn't matched a file type, the type is unsupported
            return false;
        }

        public ActionResult Index()
        {
            Session["CurrentPage"] = "XXEInjection";
            return View();
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase file)
        {
            try
            {
                if (file.ContentLength > 0)
                {
                    string _FileName = Path.GetFileName(file.FileName);
                    string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
                    byte[] image = new byte[file.ContentLength];
                    file.InputStream.Read(image, 0, image.Length);
                    if (ValidateFile(file.FileName, image, 100000, FileExtension.gif, FileExtension.jpeg, FileExtension.jpg, FileExtension.png))
                    {
                        file.SaveAs(_path);

                        ViewBag.successMessage = "File Uploaded Successfully!!";
                    }
                    else
                    {
                        ViewBag.errorMessage = "File type invalid!!";
                    }
                }
                else
                {
                    ViewBag.errorMessage = "File can not be blank!!";
                }
                return View();
            }
            catch
            {
                ViewBag.errorMessage = "File upload failed!!";
                return View();
            }
        }
    }
}