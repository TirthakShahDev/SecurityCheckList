﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Models.SessionSniffing;

namespace SecurityCheckList.Areas.Prevention.Controllers
{
    public class BrokenAccessController : Controller
    {
        public ActionResult Index()
        {
            Session["CurrentPage"] = "BrokenAccess";
            User Userdata = new User();
            return View(Userdata);
        }

        [HttpPost]
        public ActionResult Index(User model)
        {
            User user = new User() { Email = model.Email.ToString().Trim(), Password = model.Password.ToString().Trim() };
            string validUser = string.Empty;
            user = SecurityCheckList.DAL.Repository.GetUserDetails(user, ref validUser);

            if (user != null)
            {
                setSessionData(user);
                if (user.Roles.Contains("Admin"))
                {
                    return RedirectToAction("AdminView");
                }
                else
                {
                    return RedirectToAction("AuthenticatedView");
                }
            }
            else
            {
                ModelState.AddModelError("", "Invalid " + validUser);
                return View(model);
            }
        }

        public ActionResult AdminView()
        {
            if (HttpContext.Session["UserEmail"] != null)
            {
                if (HttpContext.Session["UserRole"].ToString() == "Admin")
                {
                    return View();
                }
                else
                {
                    return RedirectToAction("UnAuthorizedView");
                }
            }
            else
            {
                return RedirectToAction("UnAuthorizedView");
            }
        }

        public ActionResult AuthenticatedView()
        {
            if (HttpContext.Session["UserEmail"] == null)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult UnAuthorizedView()
        {
            return View();
        }

        public ActionResult LogOut()
        {
            RemoveSessionData();
            return RedirectToAction("Index");
        }

        #region Session Manipulation
        public void setSessionData(User userdata)
        {
            HttpContext.Session["UserEmail"] = userdata.Email;
            HttpContext.Session["UserRole"] = userdata.Roles;
        }
        public void RemoveSessionData()
        {
            HttpContext.Session.RemoveAll();
            HttpContext.Session.Abandon();
        }
        #endregion
    }
}