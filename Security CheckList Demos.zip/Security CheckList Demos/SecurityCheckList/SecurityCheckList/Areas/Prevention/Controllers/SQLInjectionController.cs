﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Models;
using SecurityCheckList.Repository;

namespace SecurityCheckList.Areas.Prevention.Controllers
{
    public class SQLInjectionController : Controller
    {
        // GET: Prevention/SQLInjection
        public ActionResult Login()
        {
            Session["CurrentPage"] = "SQLInjection";
            return View();
        }

        [HttpPost]
        public ActionResult Login(User model)
        {
            if (model.Username != null)
            {
                GeneralPrevention obj = new GeneralPrevention();
                List<User> users = obj.verifyUser(model);

                ViewBag.Users = users;
            }
            return View();
        }
    }
}