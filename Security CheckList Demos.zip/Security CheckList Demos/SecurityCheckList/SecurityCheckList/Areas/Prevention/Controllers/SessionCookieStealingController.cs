﻿using SecurityCheckList.Models.SessionSniffing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityCheckList.Areas.Prevention.Controllers
{
    public class SessionCookieStealingController : Controller
    {
        #region Controller Actions
        public ActionResult Index()
        {
            Session["CurrentPage"] = "SessionCookieStealing";
            User Userdata = new User();
            return View(Userdata);
        }

        [HttpPost]
        public ActionResult Index(User model)
        {
            User user = new User() { Email = model.Email.ToString().Trim(), Password = model.Password.ToString().Trim() };
            string validUser = string.Empty;
            user = SecurityCheckList.DAL.Repository.GetUserDetails(user, ref validUser);

            if (user != null)
            {
                setSessionData(user);
                if (user.Roles.Contains("Admin"))
                {
                    return RedirectToAction("AdminView");
                }
                else
                {
                    return RedirectToAction("AuthenticatedView");
                }
            }
            else
            {
                ModelState.AddModelError("", "Invalid " + validUser);
                return View(model);
            }
        }

        public ActionResult AuthenticatedView()
        {
            string TempSession = Convert.ToString(HttpContext.Session["AuthenticationToken"]);
            string TempAuthCookie = Convert.ToString(HttpContext.Request.Cookies["AuthenticationToken"] != null ? HttpContext.Request.Cookies["AuthenticationToken"].Value : "");

            if (string.IsNullOrEmpty(TempSession) || string.IsNullOrEmpty(TempAuthCookie))
            {
                return RedirectToAction("Index");
            }
            else if (TempSession.Equals(TempAuthCookie) && HttpContext.Session["UserEmail"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        public ActionResult SessionSniffing()
        {
            return View();
        }

        public ActionResult LogOut()
        {
            RemoveSessionData();
            RemoveCoockieData();
            return RedirectToAction("Index");
        }

        public ActionResult AdminView()
        {
            if (HttpContext.Session["UserEmail"] == null)
            {
                return RedirectToAction("Index");
            }
            return View();
        }
        #endregion

        #region Session Manipulation
        public void setSessionData(User userdata)
        {
            HttpContext.Session["UserEmail"] = userdata.Email;
            HttpContext.Session["UserRole"] = userdata.Roles;
            // Getting New Guid
            string guid = Convert.ToString(Guid.NewGuid());
            //Storing new Guid in Session
            Session["AuthenticationToken"] = guid;
            //Adding Cookie in Browser
            Response.Cookies.Add(new HttpCookie("AuthenticationToken", guid));

        }
        public void RemoveSessionData()
        {
            HttpContext.Session.RemoveAll();
            HttpContext.Session.Abandon();
        }
        private void RemoveCoockieData()
        {
            HttpCookie aCookie;
            string cookieName;
            int limit = Request.Cookies.Count;
            for (int i = 0; i < limit; i++)
            {
                cookieName = Request.Cookies[i].Name;
                aCookie = new HttpCookie(cookieName);
                aCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(aCookie);
            }
        }
        #endregion
    }
}