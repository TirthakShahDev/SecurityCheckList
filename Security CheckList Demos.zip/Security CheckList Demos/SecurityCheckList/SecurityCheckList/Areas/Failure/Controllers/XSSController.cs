﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Models;

namespace SecurityCheckList.Areas.Failure.Controllers
{
    public class XSSController : Controller
    {
        public ActionResult Index()
        {
            Session["CurrentPage"] = "XSS";
            Employee employee = new Employee(); 
            return View(employee);
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult Index(Employee employee)
        {
            Response.AppendHeader("X-XSS-Protection", "0");
            return View("EmployeeList", employee);
        }
	}
}