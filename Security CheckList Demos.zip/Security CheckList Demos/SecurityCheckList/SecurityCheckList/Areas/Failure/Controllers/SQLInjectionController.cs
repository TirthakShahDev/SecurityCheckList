﻿using SecurityCheckList.Models;
using SecurityCheckList.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityCheckList.Areas.Failure.Controllers
{
    public class SQLInjectionController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            Session["CurrentPage"] = "SQLInjection";
            return View();
        }

        [HttpPost]
        public ActionResult Login(User model)
        {
            if (model.Username != null)
            {
                General obj = new General();
                List<User> users = obj.verifyUser(model);

                ViewBag.Users = users;
            }
            return View();
        }
	}
}