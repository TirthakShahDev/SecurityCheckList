﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SecurityCheckList.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace SecurityCheckList.Repository
{
    public class General
    {
        public List<User> verifyUser(User obj)
        {
            List<User> listObj = new List<User>();
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["dataString"].ToString(); // connection string
                SqlConnection con = new SqlConnection(constr);
                con.Open();

                string query = "select * from Users where Username = '" + obj.Username + "'";
                SqlCommand com = new SqlCommand(query, con);
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        User userdata = new User();
                        userdata.Fullname = dt.Rows[i]["Fullname"].ToString();
                        userdata.Password = dt.Rows[i]["Password"].ToString();
                        userdata.Username = dt.Rows[i]["Username"].ToString();
                        listObj.Add(userdata);
                    }
                }
                con.Close();
            }
            catch
            {
            }
            return listObj;
        }

        public void saveUserData(Userdata obj)
        {
            string constr = ConfigurationManager.ConnectionStrings["dataString"].ToString(); // connection string
            SqlConnection con = new SqlConnection(constr);
            con.Open();

            string query = "Insert into Userdata (Name, Email, Contact) values ('" + obj.Name + "','" + obj.Email + "','" + obj.Contact + "')";
            SqlCommand com = new SqlCommand(query, con);
            com.ExecuteNonQuery();
            con.Close();
            return;
        }

        public List<Userdata> selectUsers()
        {
            List<Userdata> listObj = new List<Userdata>();
            string query;
            query = "select * from Userdata";
            string constr = ConfigurationManager.ConnectionStrings["dataString"].ToString(); // connection string
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand com = new SqlCommand(query, con); // table name 
            List<Userdata> lstMovie = new List<Userdata>();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Userdata userdata = new Userdata();
                    userdata.Name = dt.Rows[i]["Name"].ToString();
                    userdata.Email = dt.Rows[i]["Email"].ToString();
                    userdata.Contact = dt.Rows[i]["Contact"].ToString();
                    listObj.Add(userdata);
                }
            }
            return listObj;
        }
    }
}