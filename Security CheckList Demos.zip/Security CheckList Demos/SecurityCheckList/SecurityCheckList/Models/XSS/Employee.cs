﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SecurityCheckList.Models
{
    public class Employee
    {
        public int Id { get; set; }

        [Required]
        [StringLength(30, ErrorMessage = "The {0} must be atleast {2} characters long.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "The {0} can not be blank.")]
        [StringLength(1000, ErrorMessage = "The {0} must be atleast {2} characters long.")]
        public string Description { get; set; } 
    }
}