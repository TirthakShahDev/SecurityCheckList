﻿
using System.Web.Mvc;
using System.Xml;
using System;
using System.IO;
using System.Text;

namespace SecurityCheckList.Areas.Failure.Controllers
{
    public class DirectoryListingController : Controller
    {
        // GET: Failure/DirectoryListing
        public ActionResult Index()
        {
            string path = Server.MapPath("~/Web.config");
            FileAttributes attributes = System.IO.File.GetAttributes(path); 

            if ((attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
            {
                // Make the file RW
                attributes = RemoveAttribute(attributes, FileAttributes.ReadOnly);
                System.IO.File.SetAttributes(path, attributes);
            } 

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(Server.MapPath("~/Web.config"));

            XmlNode n = xmlDoc.SelectSingleNode("/configuration/system.webServer/directoryBrowse");

            if (n != null)
            {
                n.Attributes["enabled"].Value = "true";
            }

            xmlDoc.Save(Server.MapPath("~/Web.config"));
            return Redirect("~/img");
        }

        private static FileAttributes RemoveAttribute(FileAttributes attributes, FileAttributes attributesToRemove)
        {
            return attributes & ~attributesToRemove;
        }
    }
}