﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityCheckList.Areas.Failure.Controllers
{
    public class ClientSideValidationController : Controller
    {
        // GET: ClientSideValidation
        [HttpGet]
        public ActionResult Index()
        {
            Session["CurrentPage"] = "ClientSideValidation";
            return View();
        }
        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            ViewBag.Message = "<strong>Success!</strong> Record inserted successfully.";
            return View();
        }
    }
}