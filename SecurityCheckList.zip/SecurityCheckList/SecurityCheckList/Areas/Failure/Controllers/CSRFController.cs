﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Models;
using SecurityCheckList.Repository;

namespace SecurityCheckList.Areas.Failure.Controllers
{
    public class CSRFController : Controller
    {
        //
        // GET: /CSRF/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Testmethod( string username)
        {
            return RedirectToAction("Index","CSRF");
        }

        [HttpPost]
        public ActionResult Index(Userdata model)
        {
            if(ModelState.IsValid)
            {
                General objGeneral = new General();
                objGeneral.saveUserData(model);
            }
            return RedirectToAction("UserList","CSRF");
        }

        public ActionResult UserList()
        {
            Session["CurrentPage"] = "CSRF";
            List< Userdata> obj = new List<Userdata>();
             General objGeneral = new General();
             obj = objGeneral.selectUsers();
            return View(obj);
        }
	}
}