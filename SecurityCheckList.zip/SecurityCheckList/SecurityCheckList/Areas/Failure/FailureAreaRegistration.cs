﻿using System.Web.Mvc;

namespace SecurityCheckList.Areas.Failure
{
    public class FailureAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Failure";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
            name: "Failure_Blank",
            url: "",
            defaults: new { controller = "SQLInjection", action = "Login" });

            context.MapRoute(
            name: "Failure",
            url: "Failure",
            defaults: new { controller = "SQLInjection", action = "Login" });

            context.MapRoute(
                "Failure_default",
                "Failure/{controller}/{action}/{id}",
                new { action = "Login", id = UrlParameter.Optional }
            );
        }
    }
}