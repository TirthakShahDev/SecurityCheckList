﻿using System.Web.Mvc;

namespace SecurityCheckList.Areas.Prevention
{
    public class PreventionAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "Prevention";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
           name: "Prevention",
           url: "Prevention",
           defaults: new { controller = "SQLInjection", action = "Login" });

            context.MapRoute(
                "Prevention_default",
                "Prevention/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                new[] { "SecurityCheckList.Areas.Prevention.Controllers" }
            );
        }
    }
}