﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Models;

namespace SecurityCheckList.Areas.Prevention.Controllers
{
    public class ReadOnlyAndDisabledfieldsController : Controller
    {
        // GET: ReadOnlyAndDisabledfields
        public ActionResult Index(string Data)
        {
            Session["CurrentPage"] = "ReadOnlyAndDisabledfields";
            List<ProductModel> product = new List<ProductModel>();
            product = ProductData(Data);
            return View(product.ToList());
        }

        [HttpGet]
        public ActionResult Edit(string ProductName)
        {
            ProductModel model = new ProductModel();
            List<ProductModel> product = new List<ProductModel>();
            product = ProductData(null);
            var data = product.Where(x => x.ProductName == ProductName);
            foreach (var item in data)
            {
                model.ProductName = item.ProductName;
                model.Quantity = item.Quantity;
                model.Price = item.Price;
                model.Total = (model.Quantity * model.Price);
            }
            return Json(new object[] { true, model }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ValidateData(string Data)
        {
            string[] Datas = null;
            if (Data != null)
            {
                Datas = Data.Split(',');
            }
            int Price = Convert.ToInt32(Datas[1]);
            int Quantity = Convert.ToInt32(Datas[2]);
            int GetTotal = Convert.ToInt32(Datas[3]);
            int Total = Price * Quantity;
            if (GetTotal == Total) {
                return Json(new object[] { true }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new object[] { false }, JsonRequestBehavior.AllowGet);
            }

        }
        public List<ProductModel> ProductData(string Data)
        {
            List<ProductModel> product = new List<ProductModel>();
            ProductModel model = new ProductModel();
            string[] Datas = null;
            if (Data != null)
            {
                Datas = Data.Split(',');
            }
            if (Data != null && Datas[0] == "p1")
            {
                model = new ProductModel();
                model.ProductID = 1;
                model.ProductName = Datas[0];
                model.Quantity = Convert.ToInt32(Datas[2]);
                model.Price = Convert.ToInt32(Datas[1]);
                model.Total = Convert.ToInt32(Datas[3]);

                Session["ProductID1"] = 1;
                Session["ProductName"] = Datas[0];
                Session["Quantity"] = Convert.ToInt32(Datas[2]);
                Session["Price"] = Convert.ToInt32(Datas[1]);
                Session["Total"] = Convert.ToInt32(Datas[3]);
            }
            else
            {
                model = new ProductModel();
                model.ProductID = 1;
                model.ProductName = "p1";
                model.Quantity = Convert.ToInt32(Session["Quantity"]).Equals(0) ? 2 : Convert.ToInt32(Session["Quantity"]);
                model.Price = Convert.ToInt32(Session["Price"]).Equals(0) ? 100 : Convert.ToInt32(Session["Price"]);
                model.Total = Convert.ToInt32(Session["Total"]).Equals(0) ? 200 : Convert.ToInt32(Session["Total"]);
            }
            product.Add(model);

            if (Data != null && Datas[0] == "p2")
            {
                model = new ProductModel();
                model.ProductID = 2;
                model.ProductName = Datas[0];
                model.Quantity = Convert.ToInt32(Datas[2]);
                model.Price = Convert.ToInt32(Datas[1]);
                model.Total = Convert.ToInt32(Datas[3]);

                Session["ProductID2"] = 2;
                Session["ProductName2"] = Datas[0];
                Session["Quantity2"] = Convert.ToInt32(Datas[2]);
                Session["Price2"] = Convert.ToInt32(Datas[1]);
                Session["Total2"] = Convert.ToInt32(Datas[3]);
            }
            else
            {
                model = new ProductModel();
                model.ProductID = 2;
                model.ProductName = "p2";
                model.Quantity = Convert.ToInt32(Session["Quantity2"]).Equals(0) ? 5 : Convert.ToInt32(Session["Quantity2"]);
                model.Price = Convert.ToInt32(Session["Price2"]).Equals(0) ? 50 : Convert.ToInt32(Session["Price2"]);
                model.Total = Convert.ToInt32(Session["Total2"]).Equals(0) ? 250 : Convert.ToInt32(Session["Total2"]);
            }

            product.Add(model);

            return product.ToList();
        }
    }
}