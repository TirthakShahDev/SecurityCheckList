﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Models.SessionSniffing;

namespace SecurityCheckList.Areas.Prevention.Controllers
{
    public class BruteForceController : Controller
    {
        public ActionResult Index()
        {
            Session["CurrentPage"] = "BruteForce";
            User Userdata = new User();
            return View(Userdata);
        }

        [HttpPost]
        public ActionResult Index(User model)
        {
            if (!CheckIfBlockuser(model.Email))
            {
                User user = new User() { Email = model.Email.ToString().Trim(), Password = model.Password.ToString().Trim() };
                string validUser = string.Empty;
                user = SecurityCheckList.DAL.Repository.GetUserDetails(user, ref validUser);

                if (user != null)
                {
                    setSessionData(user);
                    return RedirectToAction("AuthenticatedView");
                }
                else
                {
                    if (validUser == "password")
                    {
                        Dictionary<string, int> DicFaildAttempt = new Dictionary<string, int>();
                        if (Session["InvalidAttempt"] == null)
                        {
                            DicFaildAttempt.Add(model.Email, 1);
                            Session["InvalidAttempt"] = DicFaildAttempt;
                        }
                        else
                        {
                            Dictionary<string, int> DicFaildAttemptIncrease = new Dictionary<string, int>();
                            DicFaildAttemptIncrease = (Dictionary<string, int>)Session["InvalidAttempt"];
                            int count = (int)DicFaildAttemptIncrease[model.Email];
                            DicFaildAttempt.Add(model.Email, count + 1);
                            Session["InvalidAttempt"] = DicFaildAttempt;
                        }
                    }

                    ModelState.AddModelError("", "You have entered incorrect details. Please try again!");
                    return View(model);
                }
            }
            else
            {
                ModelState.AddModelError("", "Account has been blocked for "+model.Email);
                return View(model);
            }
            
        }

        public ActionResult AuthenticatedView()
        {
            if (HttpContext.Session["UserEmail"] == null)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult LogOut()
        {
            RemoveSessionData();
            return RedirectToAction("Index");
        }

        public ActionResult ResetLoginAttempt()
        {
            if (Session["InvalidAttempt"] != null)
            {
                Session["InvalidAttempt"] = null;
            }
            return RedirectToAction("Index");
        }

        #region Session Manipulation
        public void setSessionData(User userdata)
        {
            HttpContext.Session["UserEmail"] = userdata.Email;
            HttpContext.Session["UserRole"] = userdata.Roles;
        }
        public void RemoveSessionData()
        {
            HttpContext.Session.RemoveAll();
            HttpContext.Session.Abandon();
        }
        #endregion

        #region Check IF User Blocked
        public bool CheckIfBlockuser(string Email)
        {
            if (Session["InvalidAttempt"] != null)
            {
                Dictionary<string, int> DicFaildAttempt = new Dictionary<string, int>();
                DicFaildAttempt = (Dictionary<string, int>)Session["InvalidAttempt"];
                int count = 0;
                DicFaildAttempt.TryGetValue(Email, out count);
                if (count >= 3)
                {
                    return true;
                }
                else
                {
                    return false;
                }    
            }
            else
            {
                return false;
            }
            
        }
        #endregion
    }
}