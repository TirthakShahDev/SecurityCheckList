﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecurityCheckList.Models;

namespace SecurityCheckList.Areas.Prevention.Controllers
{
    public class ClientSideValidationController : Controller
    {
        // GET: Prevention/ClientSideValidation
        [HttpGet]
        public ActionResult Index()
        {
            Session["CurrentPage"] = "ClientSideValidation";
            return View();
        }
        [HttpPost]
        public ActionResult Index(FormCollection data, CustomerModel model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Message = "<div class='alert alert-success'><strong>Success!</strong> Record inserted successfully.</div>";
            }
            else {
                ViewBag.Message = "<div class='alert alert-danger'><strong> Error! </strong> Please fill required details.</div>";
            }
            return View();
        }
    }
}