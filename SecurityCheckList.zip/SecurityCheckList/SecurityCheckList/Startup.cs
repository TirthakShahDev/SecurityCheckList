﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SecurityCheckList.Startup))]
namespace SecurityCheckList
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
