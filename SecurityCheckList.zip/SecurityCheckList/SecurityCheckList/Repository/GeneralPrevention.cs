﻿using SecurityCheckList.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SecurityCheckList.Repository
{
    public class GeneralPrevention
    {
        public List<User> verifyUser(User obj)
        {
            List<User> listObj = new List<User>();
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["dataString"].ToString(); // connection string

                SqlConnection con = new SqlConnection(constr);
                con.Open();

                using (SqlCommand cmd = new SqlCommand("VerifyUser", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Username", obj.Username);
                    DataTable dt = new DataTable();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            User userdata = new User();
                            userdata.Fullname = dt.Rows[i]["Fullname"].ToString();
                            userdata.Password = dt.Rows[i]["Password"].ToString();
                            userdata.Username = dt.Rows[i]["Username"].ToString();
                            listObj.Add(userdata);
                        }
                    }
                }
                
                //add any parameters the stored procedure might require
               
                con.Close();
                //SqlConnection con = new SqlConnection(constr);
                //con.Open();

                //string query = "select * from Users where Username = '" + obj.Username + "' or Username = '' ";
                //SqlCommand com = new SqlCommand(query, con);
                //DataTable dt = new DataTable();
                //SqlDataAdapter da = new SqlDataAdapter(com);
                //da.Fill(dt);
                //if (dt.Rows.Count > 0)
                //{
                //    for (int i = 0; i < dt.Rows.Count; i++)
                //    {
                //        User userdata = new User();
                //        userdata.Fullname = dt.Rows[i]["Fullname"].ToString();
                //        userdata.Password = dt.Rows[i]["Password"].ToString();
                //        userdata.Username = dt.Rows[i]["Username"].ToString();
                //        listObj.Add(userdata);
                //    }
                //}
                //con.Close();
            }
            catch
            {
            }
            return listObj;
        }
    }
}